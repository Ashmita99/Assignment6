n=0
for i in range(5):
    n=n+1
for j in range(0,n-1):
    print('*',end="")
print()