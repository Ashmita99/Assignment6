k = True
while (k == True):
    print('yes')