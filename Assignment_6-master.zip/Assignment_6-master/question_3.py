n = []
s = []
w = int(input('Enter how many elements you want'))
for i in range(0,w):
    x = int(input('Enter the numbers into the array'))
    m=x*x
    n.append(x)
    s.append(m)
print(n)
print(s)

